package p2;

/*
 * This class extracts messages from a Buffer of MessageProducers and
 * inserts them into a Buffer of Messages, delaying each input by the 
 * time specified for each producer.
 */

public class Producer extends Thread {
	private Buffer<MessageProducer> producerBuffer;
	private Buffer<Message> messageBuffer;
	private MessageProducer producer;

	public Producer(Buffer<MessageProducer> prodBuffer, Buffer<Message> messageBuffer) {
		this.producerBuffer = prodBuffer;
		this.messageBuffer = messageBuffer;
	}

	public void run() {
		System.out.println("Producer Online.");
		System.out.println("Producer: Current producers in buffer: " + producerBuffer.size());
		System.out.println("Producer: Current messages in buffer: " + messageBuffer.size());
		while (true) {
			if (producerBuffer.size() > 0) {// Do we have a producer in the Buffer?
				try {
					producer = producerBuffer.get(); // Make a reference to the producer before the Buffer removes them
					for (int i = 0; i < producer.times(); i++) {
						for (int j = 0; j < producer.size(); j++) { // While the producer has messages
							messageBuffer.put(producer.nextMessage()); // Put the next message in the buffer
							System.out.println("Producer: Message retrieved from producer, inserted into buffer.");
							Thread.sleep(producer.delay()); // Can't use "currentThread().sleep(n)" for some reason,
															// "needs
															// to be static"
						}
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			Thread.yield(); // Our threads are not letting the scheduler move on, yield instead of sleeping
							// for maximum speed.
		}
	}
}
