package p2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * This runnable class receives MessageProducers from MessageProducerClient
 * and passes them along to MessageProducerInput. The established sockets
 * and streams are closed after each transmission.
 */
public class MessageProducerServer extends Thread {
	private MessageProducerInput mpInput;
	private int port;
	private ServerSocket serverSocket;

	public MessageProducerServer(MessageProducerInput mpInput, int port) {
		this.mpInput = mpInput;
		this.port = port;
	}

	public void startServer() {
		this.start();
	}

	public void run() {
		try {
			serverSocket = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}

		while (true) {
			try {
				Socket clientSocket = serverSocket.accept();
				ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
				System.out.println("Server: Accepted client, reading data...");
				mpInput.addMessageProducer((MessageProducer) in.readObject());
				System.out.println("Server: Data read, shutting down socket.");
				in.close();
				clientSocket.close();
			} catch (IOException | ClassNotFoundException e) {
				System.out.println("Server: Failed reading MessageProducer!");
				e.printStackTrace();
			}
			Thread.yield();
		}
	}
}
