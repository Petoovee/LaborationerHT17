package p2;

/*
 * Similarly to P1Viewer, this class serves to collect messages and 
 * show them on a Viewer. This one uses a callback technique.
 */

public class P2Viewer extends Viewer implements CallBack {

	public P2Viewer(MessageClient messageClient, int width, int height) {
		super(width, height);
		messageClient.callMeBack(this);
	}

	@Override
	public void callback(Message message) {
		System.out.println("P2Viewer: Message recieved, updating.");
		setMessage(message);
	}
}
