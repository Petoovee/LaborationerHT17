package p2;

// Interface for easy categorization into callback lists
public interface CallBack {
	public void callback(Message message);
}
