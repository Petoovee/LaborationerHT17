package p2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Observable;
import java.util.Observer;

/*
 * This runnable class observes MessageManager and forwards
 * its messages to all the connected clients.
 */
public class MessageServer extends Thread {
	MessageManager messageManager;
	int port;
	ServerSocket serverSocket;

	public MessageServer(MessageManager messageManager, int port) {
		this.messageManager = messageManager;
		this.port = port;
		this.start();
	}

	public void run() {
		try {
			serverSocket = new ServerSocket(port);
			System.out.println("MessageServer online.");
		} catch (IOException e) {
			System.err.println("MessageServer: Initialization failed.");
			e.printStackTrace();
		}
		while (true) {
			try {
				Socket clientSocket = serverSocket.accept();
				new MessageServerThread(clientSocket);
				System.out.println("MessageServer: Client connected.");
			} catch (IOException e) {
				System.err.println("MessageServer: Could not accept client.");
				e.printStackTrace();
			}
		}
	}

	class MessageServerThread extends Thread implements Observer {
		Socket clientSocket;
		Message message;
		Message prevMessage;
		ObjectOutputStream out;
		ObjectInputStream in;
		boolean messageChanged = false;

		public MessageServerThread(Socket clientSocket) {
			messageManager.addObserver(this);
			try {
				this.clientSocket = clientSocket;
				out = new ObjectOutputStream(clientSocket.getOutputStream());
			} catch (IOException e) {
				System.err.println("MessageServerThread: Could not establish streams with client.");
				e.printStackTrace();
			}
			this.start();
		}

		public void run() {
			System.out.println("MessageServerThread online.");
			while (true) {
				if (messageChanged) {
					prevMessage = message;
					try {
						out.writeObject(message);
						System.out.println("MessageServerThread: Message sent!");
					} catch (IOException e) {
						System.err.println("MessageServerThread: Could not send message.");
						e.printStackTrace();
					}
				}

				// Yield to prevent overutilizing thread
				Thread.yield();
			}
		}

		/*
		 * If the transmission was one in the update function, the process would not be
		 * multithreaded. Unless it started a new thread, in which case it is futile to
		 * start the server before an update. The current implementation wastes a lot of
		 * processor power in order to fulfill the specifications. To optimize, remove
		 * the while-loop and sleep block and uncomment the function in update()
		 */
		@Override
		public void update(Observable o, Object arg) {
			message = (Message) arg;
			System.out.println("MessageServerThread: Message received.");
			messageChanged = true;
			// this.start();
		}
	}

}
