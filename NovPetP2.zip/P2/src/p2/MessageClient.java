package p2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.LinkedList;

/*
 * This threaded class manages redistribution of incoming
 * messages to registered recipients using a callback technique. 
 */

public class MessageClient extends Thread {
	private Socket socket;
	private ObjectInputStream in;
	private String address;
	private int port;
	private LinkedList<CallBack> callBacks = new LinkedList<CallBack>();

	public MessageClient(String address, int port) {
		this.address = address;
		this.port = port;
		this.start();
	}

	public void run() {
		System.out.println("MessageClient online.");
		try {
			socket = new Socket(address, port);
		} catch (IOException e) {
			System.err.println("MessageClient: Could not establish socket to server.");
			e.printStackTrace();
		}

		try {
			in = new ObjectInputStream(socket.getInputStream());
			System.out.println("MessageClient: Stream established.");
		} catch (IOException e) {
			System.err.println("MessageClient: Could not establish streams to server.");
			e.printStackTrace();
		}

		while (true) {
			Message message;
			try {
				message = (Message) in.readObject();
				System.out.println("MessageClient: Message received.");
				for (int i = 0; i < callBacks.size(); i++) {
					callBacks.get(i).callback(message);
				}
			} catch (ClassNotFoundException | IOException e) {
				System.err.println("MessageClient: Failed to receive message!");
				e.printStackTrace();
			}
		}
	}

	public void callMeBack(CallBack callBack) {
		System.out.println("MessageClient: Callback registered.");
		callBacks.add(callBack);
	}
}
