package p2;

/*
 * The sole purpose of this class is to insert given
 * MessageProducers into a given producerBuffer.
 */
public class MessageProducerInput {
	private Buffer<MessageProducer> producerBuffer;

	public MessageProducerInput(Buffer<MessageProducer> producerBuffer) {
		this.producerBuffer = producerBuffer;
	}

	public void addMessageProducer(MessageProducer m) {
		producerBuffer.put(m);
		System.out.println("MessageProducerInput: Inserted producer. Size: " + producerBuffer.size());
	}
}