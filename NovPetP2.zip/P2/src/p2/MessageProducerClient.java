package p2;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

/*
 * This class serves to send producers to the MessageProducerServer.
 * Sockets and streams are established and closed for each object.
 */

public class MessageProducerClient {
	Socket socket;
	ObjectOutputStream dOut;
	String address;
	int port;
	MessageProducer producer;

	public MessageProducerClient(String address, int port) {
		this.address = address;
		this.port = port;
	}

	public void send(MessageProducer producer) {
		try {
			socket = new Socket(address, port);
			dOut = new ObjectOutputStream(socket.getOutputStream());
			this.producer = producer;
			dOut.writeObject(producer);
			dOut.flush();
			socket.close();
			dOut.close();
		} catch (IOException e) {
			System.out.println("Client: Failed sending MessageProducer!");
			e.printStackTrace();
		}
	}
}
