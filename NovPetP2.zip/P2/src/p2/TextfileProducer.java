package p2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/*
 * This MessageProducer class serves to reaad Messages from a text
 * file, as such it behaves similarly to other MessageProducers.
 */
public class TextfileProducer implements MessageProducer {
	private Message[] messages;
	private int delay = 0;
	private int times = 0;
	private int currentIndex = -1;

	public TextfileProducer(String filename) {
		try {
			BufferedReader fileReader = new BufferedReader(
					new InputStreamReader(new FileInputStream(filename), "UTF-8"));
			this.times = Integer.parseInt(fileReader.readLine());
			this.delay = Integer.parseInt(fileReader.readLine());
			this.messages = new Message[Integer.parseInt(fileReader.readLine())];

			for (int i = 0; i < messages.length; i++) {
				String messageString = fileReader.readLine();
				Icon messageIcon = new ImageIcon(fileReader.readLine());
				messages[i] = new Message(messageString, messageIcon);
			}
		} catch (IOException e) {
			System.out.println("Something went wrong!" + e);
		}
	}

	@Override
	public int delay() {
		return delay;
	}

	@Override
	public int times() {
		return times;
	}

	@Override
	public int size() {
		return (messages == null) ? 0 : messages.length;
	}

	@Override
	public Message nextMessage() {
		if (size() == 0)
			return null;
		currentIndex = (currentIndex + 1) % messages.length;
		return messages[currentIndex];
	}

}
