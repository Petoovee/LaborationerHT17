package p1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/*
 * This MessageProducer class is very similar to the TextFileProducer class,
 * however instead of reading a stored text file, this class reads and 
 * interprets stored objects.
 */
public class ObjectfileProducer implements MessageProducer {

	private Message[] messages;
	private int delay = 0;
	private int times = 0;
	private int currentIndex = -1;

	public ObjectfileProducer(String filename) {
		try {
			ObjectInputStream objectReader = new ObjectInputStream(new FileInputStream(filename));
			this.times = objectReader.readInt();
			this.delay = objectReader.readInt();
			this.messages = new Message[objectReader.readInt()];

			for (int i = 0; i < messages.length; i++) {
				messages[i] = (Message) objectReader.readObject();
			}
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Something went wrong!" + e);
		}
	}

	@Override
	public int delay() {
		return delay;
	}

	@Override
	public int times() {
		return times;
	}

	@Override
	public int size() {
		return (messages == null) ? 0 : messages.length;
	}

	@Override
	public Message nextMessage() {
		if (size() == 0)
			return null;
		currentIndex = (currentIndex + 1) % messages.length;
		return messages[currentIndex];
	}
}
