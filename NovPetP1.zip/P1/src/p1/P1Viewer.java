package p1;

import java.util.Observable;
import java.util.Observer;

/*
 * This class serves to collect messages and 
 * show them on a Viewer. This one uses an Observable-Observer relation.
 */
public class P1Viewer extends Viewer implements Observer {

	public P1Viewer(MessageManager messageManager, int width, int height) {
		super(width, height);
		messageManager.addObserver(this);
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		System.out.println("P1Viwer: Message recieved, updating.");
		setMessage((Message) arg1);
	}
}
