package p1;

import java.util.Observable;

/*
 * MessageManager has it's similarities to MessageClient, however instead
 * of receiving objects from a socket, this class draws the messages
 * directly from a message buffer and exchanges the callback technique
 * for a Observer-Observable relation.
 */
public class MessageManager extends Observable {
	private Buffer<Message> messageBuffer;

	public MessageManager(Buffer<Message> messageBuffer) {
		this.messageBuffer = messageBuffer;
	}

	public void start() {
		new MessageManagerThread().start();
	}

	public class MessageManagerThread extends Thread {

		public MessageManagerThread() {
		}

		public void run() {
			System.out.println("MessageManager Online.");
			while (true) {
				if (messageBuffer.size() > 0) {
					try {
						Message message = messageBuffer.get();
						System.out.println("MessageManager: Message retrieved.");
						setChanged();
						notifyObservers(message);
						System.out.println("MessageManager: Pushed message.");
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				Thread.yield(); // Our threads are not letting the scheduler move on, yield instead of sleeping
								// for maximum speed.
			}
		}
	}
}