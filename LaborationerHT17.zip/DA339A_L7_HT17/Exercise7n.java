package laboration7;
import laboration6.PaintWindow;

import javax.swing.ImageIcon;

public class Exercise7n {
	private PaintWindow window;
	private Picture man1, man2;
	
    public void action1() {
        ImageIcon image1 = new ImageIcon("images/sommar.jpg");
        ImageIcon image2 = new ImageIcon("images/liggandegubbe.jpg");
        ImageIcon image3 = new ImageIcon("images/gubbe.jpg");

        window = new PaintWindow(image1);
        window.setTitle("Uppgift 7n");
        
        int width = window.getBackgroundWidth();
        int height = window.getBackgroundHeight();
        
        man1 = new Picture(image2, 0, (height-image2.getIconHeight())/2, 3, 0); 
        man2 = new Picture(image3, (width-image3.getIconWidth())/2, height-image3.getIconHeight()); 
        showPicture(man1);
        showPicture(man2);
        movePictures();
    }
    
    public void movePictures() {
    	int x,dx;
    	int maxX = window.getBackgroundWidth()-man1.getIcon().getIconWidth();
    	while(true) {
    		x = man1.getX() + man1.getDx();
    		man1.setX(x);
    		
    		showPicture(man1);
    		
    		if(x>maxX) {
    			dx = man1.getDx();
    			man1.setDx(-dx);
    		}
    		
    		PaintWindow.pause(20);
    	}
    }
    
    public void showPicture(Picture picture) {
    	window.showImage(picture.getIcon(), picture.getX(), picture.getY());
    }
    
    public static void main(String[] args) {
        Exercise7n u7n = new Exercise7n();
        u7n.action1();
    }
}
