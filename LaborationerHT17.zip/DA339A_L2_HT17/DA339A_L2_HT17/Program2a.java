package laboration2;

public class Program2a {
    public void info() {
        // Lägg till instruktioner här
    }

    public static void main( String[] args ) {
        Program2a p2 = new Program2a();
        p2.info();
    }
}