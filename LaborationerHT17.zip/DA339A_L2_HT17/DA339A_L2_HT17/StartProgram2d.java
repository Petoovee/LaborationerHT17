package laboration2;

public class StartProgram2d {
    public static void main(String[] args) {
        Program2d p2d = new Program2d();
        p2d.nameAndJava();
    }
}
