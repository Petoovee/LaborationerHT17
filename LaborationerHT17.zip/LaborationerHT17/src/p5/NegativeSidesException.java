package p5;

public class NegativeSidesException extends RuntimeException {
	public NegativeSidesException() {
		super();
	}

	public NegativeSidesException(String message) {
		super(message);
	}
}
