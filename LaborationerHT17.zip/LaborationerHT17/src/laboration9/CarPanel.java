package laboration9;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class CarPanel extends JPanel {
	private PaintPanel paintPanel = new PaintPanel();
	private JSlider jsMove = new JSlider();
	private Car car = new Car(new ImageIcon("images/BilH.gif"));
	
	// Puts all the pieces where they need to be.
	public CarPanel() {
		setPreferredSize(new Dimension(600, 150));
		setLayout(new GridLayout(2, 1)); // Possibly redundant, given the low number of objects.
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		paintPanel.setPreferredSize(new Dimension(500, 100));
		paintPanel.showImage(car.getImage(), jsMove.getValue(), 10);
		add(paintPanel);
		jsMove.setSize(paintPanel.getWidth(), 30);
		jsMove.addChangeListener(new SliderListener());
		jsMove.setMaximum(480);
		add(jsMove);
	}
	
	/*
	 *  Uses the premade ChangeListener class from javax.swing to move the car
	 *  to where it should be with the given slider value and updates its location
	 *  on the paintPanel.
	 */
	private class SliderListener implements ChangeListener {
		public void stateChanged(ChangeEvent e) {
			car.moveTo(jsMove.getValue(), car.getY());
			paintPanel.showImage(car.getImage(), jsMove.getValue(), 10);
		}
	}

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, new CarPanel());
	}
}
