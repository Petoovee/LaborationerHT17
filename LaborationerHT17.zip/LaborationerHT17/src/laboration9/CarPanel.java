package laboration9;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class CarPanel extends JPanel {
	private PaintPanel paintPanel = new PaintPanel();
	private JSlider jsMove = new JSlider();
	private Car car = new Car(new ImageIcon("images/BilH.gif"));

	public CarPanel() {
		setPreferredSize(new Dimension(600, 150));
		setLayout(new GridLayout(2, 1));
		setBorder(BorderFactory.createLineBorder(Color.BLACK));
		paintPanel.setPreferredSize(new Dimension(500, 100));
		paintPanel.showImage(car.getImage(), jsMove.getValue(), 10);
		add(paintPanel);
		jsMove.setSize(paintPanel.getWidth(), 30);
		jsMove.addChangeListener(new SliderListener());
		jsMove.setMaximum(480);
		add(jsMove);
	}
	
	private class SliderListener implements ChangeListener {
		public void stateChanged(ChangeEvent e) {
			car.moveTo(jsMove.getValue(), car.getY());
			paintPanel.showImage(car.getImage(), jsMove.getValue(), 10);
		}
	}

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, new CarPanel());
	}
}
