package laboration9;

public class StartAll {
	public static void main(String[] args) {
		AllPanels allpanels = new AllPanels();
		allpanels.start();
	}
}
