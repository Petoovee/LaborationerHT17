package l5alarm;

public interface AlarmListener {
	public void alarm();
}
