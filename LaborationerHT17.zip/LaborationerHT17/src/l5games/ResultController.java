package l5games;

public interface ResultController {
	public void start();

	public void stop();
	// public void filter(int gameNbr);
}
