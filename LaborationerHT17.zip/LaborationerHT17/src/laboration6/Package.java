package laboration6;

public class Package {
	int length, width, depth;
	double weight;

	public void setLength(int length) {
		this.length = length;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
}
