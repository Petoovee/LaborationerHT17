/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package p6;

/**
 * The Color class defines methods for creating and converting color ints.
 * Colors are represented as packed ints, made up of 4 bytes: alpha, red, green,
 * blue. The values are unpremultiplied, meaning any transparency is stored
 * solely in the alpha component, and not in the color components. The
 * components are stored as follows (alpha << 24) | (red << 16) | (green << 8) |
 * blue. Each component ranges between 0..255 with 0 meaning no contribution for
 * that component, and 255 meaning 100% contribution. Thus opaque-black would be
 * 0xFF000000 (100% opaque but no contributions from red, green, or blue), and
 * opaque-white would be 0xFFFFFFFF
 */
public class Color {
	public static final int BLACK = 0xFF000000;
	public static final int DKGRAY = 0xFF444444;
	public static final int GRAY = 0xFF888888;
	public static final int LTGRAY = 0xFFCCCCCC;
	public static final int WHITE = 0xFFFFFFFF;
	public static final int RED = 0xFFFF0000;
	public static final int GREEN = 0xFF00FF00;
	public static final int BLUE = 0xFF0000FF;
	public static final int YELLOW = 0xFFFFFF00;
	public static final int CYAN = 0xFF00FFFF;
	public static final int MAGENTA = 0xFFFF00FF;
	public static final int TRANSPARENT = 0;

	/**
	 * Return the alpha component of a color int. This is the same as saying color
	 * >>> 24
	 * 
	 * @param color
	 *            the color
	 * @return the alpha component of the color
	 */
	public static int alpha(int color) {
		return color >>> 24;
	}

	/**
	 * Return the red component of a color int. This is the same as saying (color >>
	 * 16) & 0xFF
	 * 
	 * @param color
	 *            the color
	 * @return the red component of the color
	 */
	public static int red(int color) {
		return (color >> 16) & 0xFF;
	}

	/**
	 * Return the green component of a color int. This is the same as saying (color
	 * >> 8) & 0xFF
	 * 
	 * @param color
	 *            the color
	 * @return the green component of the color
	 */
	public static int green(int color) {
		return (color >> 8) & 0xFF;
	}

	/**
	 * Return the blue component of a color int. This is the same as saying color &
	 * 0xFF
	 * 
	 * @param color
	 *            the color
	 * @return the blue component of the color
	 */
	public static int blue(int color) {
		return color & 0xFF;
	}

	/**
	 * Return a color-int from red, green, blue components. The alpha component is
	 * implicity 255 (fully opaque). These component values should be [0..255], but
	 * there is no range check performed, so if they are out of range, the returned
	 * color is undefined.
	 * 
	 * @param red
	 *            Red component [0..255] of the color
	 * @param green
	 *            Green component [0..255] of the color
	 * @param blue
	 *            Blue component [0..255] of the color
	 * @return a color-int
	 */
	public static int rgb(int red, int green, int blue) {
		return (0xFF << 24) | (red << 16) | (green << 8) | blue;
	}

	/**
	 * Return a color-int from alpha, red, green, blue components. These component
	 * values should be [0..255], but there is no range check performed, so if they
	 * are out of range, the returned color is undefined.
	 * 
	 * @param alpha
	 *            Alpha component [0..255] of the color
	 * @param red
	 *            Red component [0..255] of the color
	 * @param green
	 *            Green component [0..255] of the color
	 * @param blue
	 *            Blue component [0..255] of the color
	 * @return a color-int
	 */
	public static int argb(int alpha, int red, int green, int blue) {
		return (alpha << 24) | (red << 16) | (green << 8) | blue;
	}

	/**
	 * Parse the color string, and return the corresponding color-int. If the string
	 * cannot be parsed, throws an IllegalArgumentException exception. Supported
	 * formats are: #RRGGBB #AARRGGBB
	 * 
	 * @param colorString
	 *            the color string to parse
	 * @return a color-int
	 */
	public static int parseColor(String colorString) throws IllegalArgumentException {
		if (colorString.charAt(0) == '#') {
			// Use a long to avoid rollovers on #ffXXXXXX
			long color = Long.parseLong(colorString.substring(1), 16);
			if (colorString.length() == 7) {
				// Set the alpha value
				color |= 0x00000000ff000000;
			} else if (colorString.length() != 9) {
				throw new IllegalArgumentException("Unknown color");
			}
			return (int) color;
		}
		throw new IllegalArgumentException("Unknown color");
	}

	public static String toString(int color) {
		return "[alpha=" + Color.alpha(color) + ",red=" + Color.red(color) + ",green=" + Color.green(color) + ",blue="
				+ Color.blue(color) + "]";
	}
}
