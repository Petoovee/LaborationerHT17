package workshop6;

public class BookCopy {

}
