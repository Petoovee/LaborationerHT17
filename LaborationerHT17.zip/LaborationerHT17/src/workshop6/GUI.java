package workshop6;

public class GUI {

}
