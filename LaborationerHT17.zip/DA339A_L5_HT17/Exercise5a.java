package laboration5;

/**
 * Träna for-loop 
 * @author Rolf Axelsson
 */
public class Exercise5a {
    public void exercise5a0() {
        for( int i = 0 ; i < 10 ; i++ ) {
            System.out.print( 'A' + " ");
        }
    }

    public static void main(String[] args) {
        Exercise5a e5a = new Exercise5a();
        e5a.exercise5a0();
//        System.out.println();
//        e5a.exercise5a1();
//        System.out.println();
//        e5a.exercise5a2();
//        System.out.println();
//        e5a.exercise5a3();
//        System.out.println();
//        e5a.exercise5a4();
//        System.out.println();
//        e5a.exercise5a5();
//        System.out.println();
//        e5a.exercise5a6();
    }
}
