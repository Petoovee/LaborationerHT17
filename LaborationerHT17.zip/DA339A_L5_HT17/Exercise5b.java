package laboration5;

/**
 * Träna while-loop
 * @author Rolf Axelsson
 */
public class Exercise5b {
    public void exercise5b0() {
        int i = 0;
        while( i < 10 ) {
            System.out.print( 'A' + " ");
            i++;
        }
    }
    
    public static void main(String[] args) {
        Exercise5b e5b = new Exercise5b();
        e5b.exercise5b0();
//        System.out.println();
//        e5b.exercise5b1();
//        System.out.println();
//        e5b.exercise5b2();
//        System.out.println();
//        e5b.exercise5b3();
//        System.out.println();
//        e5b.exercise5b4();
//        System.out.println();
//        e5b.exercise5b5();
//        System.out.println();
//        e5b.exercise5b6();
    }
}
