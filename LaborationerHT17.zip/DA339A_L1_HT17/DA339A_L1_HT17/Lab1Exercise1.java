/*
 * Lab1Exercise1.java
 * Skapad den 2 september 2014
 */
import javax.swing.JOptionPane;

/**
 * Programmet skriver ut "Ett java-program" med hj�lp av ett dialogf�nster.
 * 
 * @author Rolf axelsson
 * @version 1.0
 */
public class Lab1Exercise1 {

    /*
     * Metoden visar texten "Ett java-program" i ett dialogf�nster.
     */
    public void message() {
        // Ett dialogf�nster �ppnas med meddelandet "Ett java-program".
        JOptionPane.showMessageDialog( null, "Ett java-program" );
    }

    /*
     * Instruktionerna i main-metoden utf�rs d� programmet exekveras.
     * main-metoden har endast tv� instruktioner.
     * - den f�rsta instruktionen skapar ett objekt av typen Lab2Exercise1
     * - den andra instruktionen anropar metoden message i det nyss skapade objektet
     */
    public static void main( String[] args ) {
        Lab1Exercise1 prog = new Lab1Exercise1();
        prog.message();
    }
}
