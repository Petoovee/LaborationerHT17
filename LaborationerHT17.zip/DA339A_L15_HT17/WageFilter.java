package laboration15;

public interface WageFilter {
    public boolean accept( WageEmployee employed );
}
