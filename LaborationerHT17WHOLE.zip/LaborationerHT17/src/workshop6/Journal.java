package workshop6;

public class Journal {
	long itemID;
	short loanPeriod;
	boolean onLease;
}
