package workshop6;

public class Borrower {
	String name, address;
}
