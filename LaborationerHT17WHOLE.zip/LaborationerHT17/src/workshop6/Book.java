package workshop6;

public class Book {

}
