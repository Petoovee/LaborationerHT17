package laboration9;

import javax.swing.JPanel;


public class CarPanel extends JPanel{
	
	public static void main(String[] args) {
		PaintPanel window = new PaintPanel( );
		
	}
}
