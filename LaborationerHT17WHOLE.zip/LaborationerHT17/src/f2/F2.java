package f2;

import java.util.ArrayList;
import java.util.LinkedList;

public class F2 {
	public static void main(String[] args) {
		ArrayList<ArrayList<Integer>> listlist = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> arraylist = new ArrayList<Integer>();
		LinkedList<Integer> linkedlist = new LinkedList<Integer>();
		int i = 0;

		while (true) {
			linkedlist.listIterator().add(i);
			i++;
			if (i > 5000000)
				;
		}
	}
}