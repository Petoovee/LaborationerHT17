package laboration8;

public class Exercise8i {
	public static void main(String[] args) {
		Point p1 = new Point(11, 13);
		Point p2 = p1.copy();
		System.out.println(p1.toString());
		System.out.println(p2.toString());
	}
}
