package laboration10;

import javax.swing.JOptionPane;

public class SurveyApp {
	public static void main(String[] args) {
		SurveyPanel panel = new SurveyPanel();
		JOptionPane.showMessageDialog(null, panel);
	}
}
